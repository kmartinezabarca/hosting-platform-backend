# Hosting Platform Backend - Arquitectura Refactorizada

## Resumen Ejecutivo

Este documento describe la refactorización completa del backend de la plataforma de hosting, implementando una arquitectura modular profesional que separa claramente las responsabilidades entre los módulos de Cliente y Administrador. La refactorización mantiene toda la funcionalidad existente mientras mejora significativamente la organización, mantenibilidad y escalabilidad del código.

## Cambios Implementados

### 1. Arquitectura Modular

#### Estructura Anterior
```
app/Http/Controllers/
├── AuthController.php
├── AdminController.php
├── ServiceController.php
├── PaymentController.php
└── ... (todos los controladores mezclados)
```

#### Nueva Estructura Modular
```
app/Http/Controllers/
├── Controller.php                    # Controlador base de Laravel
├── Auth/                            # Módulo de Autenticación
│   ├── AuthController.php
│   ├── GoogleLoginController.php
│   └── TwoFactorController.php
├── Common/                          # Controladores compartidos
│   └── StripeWebhookController.php
├── Client/                          # Módulo Cliente
│   ├── DashboardController.php
│   ├── ProfileController.php
│   ├── ServiceController.php
│   ├── PaymentController.php
│   ├── SubscriptionController.php
│   ├── TicketController.php
│   ├── InvoiceController.php
│   ├── TransactionController.php
│   ├── DomainController.php
│   ├── ProductController.php
│   ├── CategoryController.php
│   ├── BillingCycleController.php
│   ├── ServicePlanController.php
│   └── AddOnController.php
└── Admin/                           # Módulo Administrador
    ├── AdminController.php
    ├── AgentController.php
    ├── ProductController.php
    ├── CategoryController.php
    ├── BillingCycleController.php
    ├── ServicePlanController.php
    └── AddOnController.php
```

### 2. Organización de Rutas Modulares

#### Estructura Anterior
- `routes/api.php`: Rutas públicas mezcladas
- `routes/web.php`: Todas las rutas protegidas en un solo archivo (400+ líneas)

#### Nueva Estructura Modular
```
routes/
├── api.php          # Rutas públicas (sin autenticación)
├── web.php          # Configuración base y inclusión de módulos
├── auth.php         # Rutas de autenticación compartidas
├── client.php       # Rutas específicas del módulo Cliente
└── admin.php        # Rutas específicas del módulo Administrador
```

### 3. Organización de Requests

#### Nueva Estructura
```
app/Http/Requests/
├── Auth/                            # Requests de autenticación
├── Client/                          # Requests del módulo Cliente
│   ├── Profile/
│   ├── Service/
│   ├── Payment/
│   ├── Ticket/
│   └── Domain/
└── Admin/                           # Requests del módulo Administrador
    ├── User/
    ├── Service/
    ├── Product/
    ├── Category/
    ├── ServicePlan/
    ├── AddOn/
    └── Agent/
```

## Beneficios de la Refactorización

### 1. Mantenibilidad Mejorada
- **Separación clara de responsabilidades**: Los desarrolladores pueden localizar rápidamente el código relacionado con funcionalidades específicas.
- **Reducción de conflictos**: Cambios en funcionalidades de administrador no afectan accidentalmente las funcionalidades de cliente.
- **Código más limpio**: Cada módulo tiene su propio contexto y responsabilidades bien definidas.

### 2. Escalabilidad
- **Arquitectura extensible**: Fácil agregar nuevos módulos (API para terceros, reportes, etc.).
- **Deployment selectivo**: Posibilidad futura de desplegar módulos específicos de manera independiente.
- **Testing mejorado**: Tests organizados por módulos para mejor cobertura y mantenimiento.

### 3. Experiencia de Desarrollo
- **Onboarding más rápido**: Nuevos desarrolladores entienden la estructura más fácilmente.
- **Navegación intuitiva**: Estructura de archivos que refleja la lógica de negocio.
- **Menos errores**: Menor probabilidad de modificar archivos incorrectos.

## Servicios de Terceros Identificados

### Servicios Requeridos para Funcionalidad Completa

#### 1. Proxmox VE (Virtualización)
**Estado**: ⚠️ Requiere instalación e integración

**Instalación requerida**:
```bash
# Instalar Proxmox VE 7.x o superior en servidor dedicado
# Configurar usuario API con permisos adecuados
# Documentación: https://pve.proxmox.com/wiki/Proxmox_VE_API
```

**Configuración en `.env`**:
```env
PROXMOX_URL=https://proxmox.yourdomain.com:8006
PROXMOX_USERNAME=api@pve
PROXMOX_PASSWORD=secure_api_password
PROXMOX_DEFAULT_NODE=pve
```

**Integración pendiente**:
- Cliente HTTP para comunicación con API REST de Proxmox
- Creación automática de VMs/Contenedores
- Gestión de recursos y monitoreo

#### 2. Pterodactyl Panel (Servidores de Juegos)
**Estado**: ⚠️ Requiere instalación e integración

**Instalación requerida**:
```bash
# Instalar Pterodactyl Panel v1.x
# Configurar Application API Key con permisos de escritura
# Documentación: https://pterodactyl.io/project/introduction.html
```

**Configuración en `.env`**:
```env
PTERODACTYL_URL=https://panel.yourdomain.com
PTERODACTYL_API_KEY=your_application_api_key
```

**Integración pendiente**:
- Cliente para API REST de Pterodactyl
- Creación automática de servidores de juegos
- Gestión de configuraciones y mods

#### 3. Namecheap (Registrador de Dominios)
**Estado**: ⚠️ Requiere configuración e integración

**Configuración en `.env`**:
```env
NAMECHEAP_API_USER=your_username
NAMECHEAP_API_KEY=your_api_key
NAMECHEAP_CLIENT_IP=your_server_ip
NAMECHEAP_SANDBOX=true
```

**Integración pendiente**:
- Integración con API de Namecheap
- Registro automático de dominios
- Gestión de DNS y renovaciones

#### 4. PayPal (Procesamiento de Pagos)
**Estado**: ⚠️ Requiere integración

**Configuración en `.env`**:
```env
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
PAYPAL_MODE=sandbox
```

**Integración pendiente**:
- Integración completa con PayPal SDK
- Procesamiento de pagos PayPal
- Webhooks de PayPal

### Servicios Correctamente Configurados

#### 1. Stripe (Procesamiento de Pagos)
**Estado**: ✅ Completamente integrado
- Procesamiento de pagos implementado
- Gestión de métodos de pago funcional
- Webhooks configurados y funcionando

#### 2. Configuraciones de Base de Datos y Cache
**Estado**: ✅ Correctamente configurado
- MySQL/MariaDB configurado
- Redis para cache y sesiones configurado
- Variables de entorno apropiadas

## Estructura de Base de Datos

### Tablas Clave para Servicios de Terceros

#### `server_nodes`
```sql
- id, uuid, name, hostname, ip_address
- location, node_type (proxmox|pterodactyl|dedicated)
- specifications (JSON), api_credentials (JSON encriptado)
- status, max_services, current_services
```

#### `services`
```sql
- id, uuid, user_id, product_id, server_node_id
- name, status, external_id (ID en Proxmox/Pterodactyl)
- connection_details (JSON), configuration (JSON)
- billing_cycle, price, setup_fee
```

## Configuración para Producción

### 1. Variables de Entorno Críticas

#### Aplicación
```env
APP_NAME="Tu Plataforma de Hosting"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://tudominio.com
```

#### Base de Datos
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=hosting_platform_prod
DB_USERNAME=hosting_user
DB_PASSWORD=contraseña_segura_produccion
```

#### Cache y Sesiones
```env
CACHE_DRIVER=redis
SESSION_DRIVER=redis
REDIS_HOST=127.0.0.1
REDIS_PASSWORD=contraseña_redis_segura
```

#### Seguridad
```env
SANCTUM_STATEFUL_DOMAINS=tudominio.com,app.tudominio.com
SESSION_DOMAIN=.tudominio.com
```

### 2. Servicios de Infraestructura Requeridos

#### En el Servidor Principal
- **PHP 8.1+** con extensiones: mysql, redis, curl, json, mbstring
- **MySQL 8.0+** o **MariaDB 10.5+**
- **Redis 6.0+** para cache y sesiones
- **Nginx** o **Apache** como servidor web
- **Supervisor** para gestión de colas (opcional pero recomendado)

#### Servidores Adicionales
- **Servidor Proxmox**: Para virtualización y VPS
- **Servidor Pterodactyl**: Para servidores de juegos
- **Servicio SMTP**: Mailgun, SendGrid, o similar

### 3. Configuración de Seguridad

#### Encriptación de Credenciales
```php
// Las credenciales de API se almacenan encriptadas
$credentials = encrypt([
    'username' => $username,
    'password' => $password,
    'api_key' => $api_key
]);
```

#### Rate Limiting
- Configurar límites de velocidad para APIs externas
- Implementar throttling para endpoints críticos

#### Validación de Webhooks
- Stripe: ✅ Implementado
- PayPal: ⚠️ Pendiente implementar
- Otros servicios: ⚠️ Implementar según necesidad

## Guía de Migración

### 1. Backup de Seguridad
```bash
# Crear backup completo antes de la migración
mysqldump -u usuario -p base_datos > backup_pre_refactor.sql
tar -czf codigo_original.tar.gz /ruta/al/proyecto/original
```

### 2. Actualización de Dependencias
```bash
# Actualizar composer dependencies si es necesario
composer update
```

### 3. Migración de Base de Datos
```bash
# Ejecutar migraciones si hay cambios pendientes
php artisan migrate
```

### 4. Limpieza de Cache
```bash
# Limpiar todos los caches
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan cache:clear
```

### 5. Verificación Post-Migración
- Verificar que todas las rutas respondan correctamente
- Probar funcionalidades críticas (login, pagos, creación de servicios)
- Monitorear logs por errores

## Próximos Pasos Recomendados

### Inmediatos (Semana 1-2)
1. **Configurar servicios de infraestructura** (Redis, MySQL optimizado)
2. **Implementar integración con Proxmox** para VPS
3. **Configurar servicio SMTP** para emails transaccionales

### Corto Plazo (Mes 1)
1. **Implementar integración con Pterodactyl** para servidores de juegos
2. **Desarrollar integración con PayPal** como método de pago alternativo
3. **Configurar monitoreo y alertas** para servicios críticos

### Mediano Plazo (Mes 2-3)
1. **Implementar integración con Namecheap** para dominios
2. **Desarrollar panel de administración avanzado** para gestión de nodos
3. **Implementar sistema de backups automáticos**

### Largo Plazo (Mes 4+)
1. **Desarrollar API pública** para integraciones de terceros
2. **Implementar sistema de afiliados**
3. **Agregar soporte para múltiples proveedores** de cada servicio

## Contacto y Soporte

Para preguntas sobre la implementación o necesidad de asistencia técnica adicional, contactar al equipo de desarrollo con este documento como referencia.

---

**Documento generado por**: Manus AI  
**Fecha**: Septiembre 2025  
**Versión**: 1.0  
**Estado del proyecto**: Listo para producción con integraciones pendientes identificadas

