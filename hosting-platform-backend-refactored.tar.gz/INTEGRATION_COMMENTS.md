# Comentarios de Integración para Servicios de Terceros

Este archivo contiene los comentarios específicos que deben agregarse al código para indicar dónde se requieren las integraciones con servicios de terceros.

## Comentarios para ServiceController.php

### En el método contractService() - Línea aproximada 150
```php
// TODO: INTEGRACIÓN PROXMOX/PTERODACTYL REQUERIDA
// Después de crear el servicio en la base de datos, se debe:
// 1. Determinar el nodo de servidor apropiado basado en el tipo de servicio
// 2. Crear el servicio en el sistema externo (Proxmox VE o Pterodactyl)
// 3. Actualizar el campo 'external_id' con el ID del servicio creado
// 4. Actualizar 'connection_details' con IP, puertos, credenciales de acceso
// 
// Ejemplo para Proxmox:
// $proxmoxClient = new ProxmoxClient(config('proxmox'));
// $vmId = $proxmoxClient->createVM($service->configuration);
// $service->update(['external_id' => $vmId]);
//
// Ejemplo para Pterodactyl:
// $pterodactylClient = new PterodactylClient(config('pterodactyl'));
// $serverId = $pterodactylClient->createServer($service->configuration);
// $service->update(['external_id' => $serverId]);
```

### En el método getServiceDetails() - Línea aproximada 300
```php
// TODO: INTEGRACIÓN PROXMOX/PTERODACTYL REQUERIDA
// Obtener información en tiempo real del servicio desde el sistema externo
// 
// if ($service->serverNode->node_type === 'proxmox') {
//     $proxmoxClient = new ProxmoxClient($service->serverNode->api_credentials);
//     $vmStatus = $proxmoxClient->getVMStatus($service->external_id);
//     $service->real_time_status = $vmStatus;
// } elseif ($service->serverNode->node_type === 'pterodactyl') {
//     $pterodactylClient = new PterodactylClient($service->serverNode->api_credentials);
//     $serverStatus = $pterodactylClient->getServerStatus($service->external_id);
//     $service->real_time_status = $serverStatus;
// }
```

### En el método suspendService() - Línea aproximada 400
```php
// TODO: INTEGRACIÓN PROXMOX/PTERODACTYL REQUERIDA
// Suspender el servicio en el sistema externo
//
// if ($service->serverNode->node_type === 'proxmox') {
//     $proxmoxClient = new ProxmoxClient($service->serverNode->api_credentials);
//     $proxmoxClient->stopVM($service->external_id);
// } elseif ($service->serverNode->node_type === 'pterodactyl') {
//     $pterodactylClient = new PterodactylClient($service->serverNode->api_credentials);
//     $pterodactylClient->suspendServer($service->external_id);
// }
```

## Comentarios para DomainController.php

### En el método store() - Línea aproximada 50
```php
// TODO: INTEGRACIÓN NAMECHEAP REQUERIDA
// Registrar el dominio automáticamente usando la API de Namecheap
//
// $namecheapClient = new NamecheapClient([
//     'api_user' => config('namecheap.api_user'),
//     'api_key' => config('namecheap.api_key'),
//     'client_ip' => config('namecheap.client_ip'),
//     'sandbox' => config('namecheap.sandbox')
// ]);
//
// $registrationResult = $namecheapClient->registerDomain([
//     'domain' => $request->domain_name,
//     'years' => $request->years,
//     'registrant' => $user->toNamecheapContact(),
//     'admin' => $user->toNamecheapContact(),
//     'tech' => $user->toNamecheapContact(),
//     'billing' => $user->toNamecheapContact()
// ]);
//
// if ($registrationResult->success) {
//     $domain->update(['external_id' => $registrationResult->domain_id]);
// }
```

### En el método checkAvailability() - Línea aproximada 100
```php
// TODO: INTEGRACIÓN NAMECHEAP REQUERIDA
// Verificar disponibilidad del dominio usando la API de Namecheap
//
// $namecheapClient = new NamecheapClient(config('namecheap'));
// $availability = $namecheapClient->checkDomainAvailability($request->domain);
// 
// return response()->json([
//     'available' => $availability->available,
//     'price' => $availability->price,
//     'premium' => $availability->premium
// ]);
```

## Comentarios para PaymentController.php

### En el método processPayment() - Línea aproximada 200
```php
// TODO: INTEGRACIÓN PAYPAL REQUERIDA
// Agregar soporte para procesamiento de pagos con PayPal
//
// if ($request->payment_method === 'paypal') {
//     $paypalClient = new PayPalClient([
//         'client_id' => config('paypal.client_id'),
//         'client_secret' => config('paypal.client_secret'),
//         'mode' => config('paypal.mode') // sandbox o live
//     ]);
//
//     $payment = $paypalClient->createPayment([
//         'amount' => $request->amount,
//         'currency' => 'USD',
//         'description' => $request->description,
//         'return_url' => route('paypal.success'),
//         'cancel_url' => route('paypal.cancel')
//     ]);
//
//     return response()->json(['approval_url' => $payment->getApprovalLink()]);
// }
```

## Comentarios para Modelos

### En app/Models/ServerNode.php
```php
// TODO: MÉTODOS DE INTEGRACIÓN REQUERIDOS
// Agregar métodos para interactuar con los servicios externos
//
// public function getApiClient()
// {
//     $credentials = decrypt($this->api_credentials);
//     
//     switch ($this->node_type) {
//         case 'proxmox':
//             return new ProxmoxClient([
//                 'hostname' => $this->hostname,
//                 'username' => $credentials['username'],
//                 'password' => $credentials['password']
//             ]);
//         case 'pterodactyl':
//             return new PterodactylClient([
//                 'url' => $credentials['url'],
//                 'api_key' => $credentials['api_key']
//             ]);
//         default:
//             throw new Exception('Unsupported node type');
//     }
// }
//
// public function testConnection()
// {
//     try {
//         $client = $this->getApiClient();
//         return $client->ping();
//     } catch (Exception $e) {
//         return false;
//     }
// }
```

### En app/Models/Service.php
```php
// TODO: MÉTODOS DE GESTIÓN EXTERNA REQUERIDOS
// Agregar métodos para gestionar el servicio en sistemas externos
//
// public function createExternalService()
// {
//     if (!$this->serverNode) {
//         throw new Exception('No server node assigned');
//     }
//
//     $client = $this->serverNode->getApiClient();
//     
//     switch ($this->serverNode->node_type) {
//         case 'proxmox':
//             return $client->createVM($this->configuration);
//         case 'pterodactyl':
//             return $client->createServer($this->configuration);
//     }
// }
//
// public function getExternalStatus()
// {
//     if (!$this->external_id || !$this->serverNode) {
//         return 'unknown';
//     }
//
//     $client = $this->serverNode->getApiClient();
//     return $client->getStatus($this->external_id);
// }
```

## Archivos de Configuración Requeridos

### config/proxmox.php
```php
<?php
// TODO: CREAR ARCHIVO DE CONFIGURACIÓN PROXMOX
return [
    'default_url' => env('PROXMOX_URL'),
    'default_username' => env('PROXMOX_USERNAME'),
    'default_password' => env('PROXMOX_PASSWORD'),
    'default_node' => env('PROXMOX_DEFAULT_NODE', 'pve'),
    'verify_ssl' => env('PROXMOX_VERIFY_SSL', true),
    'timeout' => env('PROXMOX_TIMEOUT', 30)
];
```

### config/pterodactyl.php
```php
<?php
// TODO: CREAR ARCHIVO DE CONFIGURACIÓN PTERODACTYL
return [
    'url' => env('PTERODACTYL_URL'),
    'api_key' => env('PTERODACTYL_API_KEY'),
    'verify_ssl' => env('PTERODACTYL_VERIFY_SSL', true),
    'timeout' => env('PTERODACTYL_TIMEOUT', 30)
];
```

### config/namecheap.php
```php
<?php
// TODO: CREAR ARCHIVO DE CONFIGURACIÓN NAMECHEAP
return [
    'api_user' => env('NAMECHEAP_API_USER'),
    'api_key' => env('NAMECHEAP_API_KEY'),
    'client_ip' => env('NAMECHEAP_CLIENT_IP'),
    'sandbox' => env('NAMECHEAP_SANDBOX', true),
    'api_url' => env('NAMECHEAP_SANDBOX', true) 
        ? 'https://api.sandbox.namecheap.com/xml.response'
        : 'https://api.namecheap.com/xml.response'
];
```

## Clases de Cliente Requeridas

### app/Services/ProxmoxClient.php
```php
<?php
// TODO: CREAR CLIENTE PROXMOX
// Implementar cliente HTTP para comunicación con API de Proxmox VE
// Documentación: https://pve.proxmox.com/wiki/Proxmox_VE_API
//
// class ProxmoxClient
// {
//     public function __construct($config) { ... }
//     public function createVM($config) { ... }
//     public function getVMStatus($vmid) { ... }
//     public function stopVM($vmid) { ... }
//     public function startVM($vmid) { ... }
//     public function deleteVM($vmid) { ... }
// }
```

### app/Services/PterodactylClient.php
```php
<?php
// TODO: CREAR CLIENTE PTERODACTYL
// Implementar cliente HTTP para comunicación con API de Pterodactyl
// Documentación: https://dashflo.net/docs/api/pterodactyl/v1/
//
// class PterodactylClient
// {
//     public function __construct($config) { ... }
//     public function createServer($config) { ... }
//     public function getServerStatus($serverId) { ... }
//     public function suspendServer($serverId) { ... }
//     public function unsuspendServer($serverId) { ... }
//     public function deleteServer($serverId) { ... }
// }
```

### app/Services/NamecheapClient.php
```php
<?php
// TODO: CREAR CLIENTE NAMECHEAP
// Implementar cliente HTTP para comunicación con API de Namecheap
// Documentación: https://www.namecheap.com/support/api/
//
// class NamecheapClient
// {
//     public function __construct($config) { ... }
//     public function checkDomainAvailability($domain) { ... }
//     public function registerDomain($config) { ... }
//     public function renewDomain($domain, $years) { ... }
//     public function setDNS($domain, $nameservers) { ... }
// }
```

---

**Nota**: Todos estos comentarios deben agregarse al código en las ubicaciones especificadas para guiar la implementación futura de las integraciones con servicios de terceros.

