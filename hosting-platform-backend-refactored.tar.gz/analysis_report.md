
## Análisis Inicial de Rutas

### `routes/api.php`
Este archivo contiene rutas públicas que no requieren autenticación. Son principalmente para funcionalidades de cara al cliente que no necesitan una sesión activa, o para webhooks externos como el de Stripe.

**Rutas identificadas:**
- Autenticación pública (registro, login, Google callback, verificación 2FA inicial).
- Webhook de Stripe.
- Rutas públicas para productos, categorías, ciclos de facturación y planes de servicio.

### `routes/web.php`
Este archivo contiene rutas que requieren una sesión de usuario activa (stateful) y están protegidas por middleware de autenticación. Incluye tanto funcionalidades de usuario final (cliente) como rutas de administración protegidas por un middleware 'admin'.

**Rutas identificadas:**
- **Rutas de autenticación protegidas:** logout, `me`, `user`.
- **Gestión de Dashboard:** estadísticas, servicios, actividad.
- **Gestión de Perfil:** obtener/actualizar perfil, avatar, email, contraseña, sesiones, seguridad, eliminar cuenta, revocar sesiones.
- **Autenticación de Dos Factores (gestión):** estado, generar, habilitar, deshabilitar, verificar.
- **Gestión de Servicios:** planes, contratar, servicios de usuario, detalles de servicio, facturas de servicio, configuración, cancelar, suspender, reactivar, uso, backups.
- **Gestión de Pagos:** métodos de pago, añadir/actualizar/eliminar métodos, setup intent, procesar pago, estadísticas, transacciones.
- **Gestión de Suscripciones:** obtener/crear/detalles/cancelar/reanudar suscripciones.
- **Gestión de Tickets:** listar, crear, estadísticas, mostrar, responder, cerrar.
- **Gestión de Facturas:** listar, estadísticas, mostrar, descargar PDF/XML.
- **Gestión de Transacciones:** listar, estadísticas, recientes, mostrar.
- **Gestión de Dominios:** listar, crear, estadísticas, verificar disponibilidad, mostrar, actualizar, renovar.

- **Rutas de ADMINISTRADOR (protegidas por middleware `admin`):**
  - Dashboard de administrador.
  - Gestión de Usuarios: listar, crear, actualizar, eliminar, actualizar estado.
  - Gestión de Servicios: listar, actualizar estado.
  - Gestión de Facturas: listar, crear, actualizar, eliminar, actualizar estado, marcar como pagada, enviar recordatorio, cancelar.
  - Gestión de Tickets: listar, actualizar estado/prioridad, asignar, responder, categorías de tickets, agentes de soporte.
  - Gestión de Agentes: listar, crear, estadísticas, recomendado, mostrar, actualizar, eliminar, asignar ticket, tickets del agente.
  - Gestión de Productos (Admin): crear, actualizar, eliminar.
  - Gestión de Add-ons: listar, crear, mostrar, actualizar, eliminar, adjuntar/desadjuntar a plan.
  - Gestión de Categorías (Admin): listar, crear, actualizar, eliminar.
  - Gestión de Ciclos de Facturación (Admin): listar, crear, actualizar, eliminar.
  - Gestión de Planes de Servicio (Admin): listar, crear, actualizar, eliminar.

**Observaciones iniciales:**
- Existe una clara separación lógica entre rutas públicas (`api.php`) y rutas protegidas (`web.php`).
- Dentro de `web.php`, las rutas de administrador están agrupadas bajo un prefijo `/admin` y protegidas por un middleware `admin`.
- Varios controladores se utilizan tanto para funcionalidades de cliente como de administrador (ej. `ProductController`, `CategoryController`, `BillingCycleController`, `ServicePlanController`), pero se importan con alias (`AdminProductController`, etc.) para las rutas de admin. Esto sugiere que la lógica de negocio para admin y cliente podría estar mezclada en algunos controladores o que hay duplicidad de controladores con el mismo nombre pero diferente contexto.
- La estructura actual de controladores está centralizada en `app/Http/Controllers`, lo que dificulta la separación modular. Será necesario mover estos controladores a subdirectorios específicos de `Client` y `Admin`.
- Las rutas están definidas directamente en los archivos `api.php` y `web.php`. Para una arquitectura modular, se podrían considerar archivos de rutas específicos para cada módulo (ej. `routes/client.php`, `routes/admin.php`) o incluso subdirectorios de rutas dentro de cada módulo.

**Próximos pasos:**
- Definir la nueva estructura de directorios para los módulos de cliente y admin.
- Planificar la migración de controladores, requests, y rutas a sus respectivos módulos.



## Análisis de Controladores (`app/Http/Controllers`)

Se ha analizado el directorio `app/Http/Controllers` para identificar la función de cada controlador y su pertenencia a los módulos de Cliente o Administrador, o si son compartidos.

**Controladores identificados y su posible clasificación:**

*   **Controladores de Administrador:**
    *   `AdminAddOnController.php`: Gestión de Add-ons por parte del administrador.
    *   `AdminController.php`: Controlador principal para diversas funcionalidades administrativas (usuarios, servicios, facturas, tickets).
    *   `AgentController.php`: Gestión de agentes de soporte, típicamente una función administrativa.

*   **Controladores de Cliente:**
    *   `AddOnController.php`: Probablemente para la gestión de Add-ons por parte del cliente (diferente del `AdminAddOnController`).
    *   `DashboardController.php`: Vistas y datos del panel de control del usuario.
    *   `DomainController.php`: Gestión de dominios por parte del cliente.
    *   `InvoiceController.php`: Gestión de facturas por parte del cliente (descarga, visualización).
    *   `PaymentController.php`: Gestión de pagos y métodos de pago del cliente.
    *   `ProfileController.php`: Gestión del perfil del usuario.
    *   `ServiceController.php`: Gestión de servicios contratados por el cliente.
    *   `SubscriptionController.php`: Gestión de suscripciones del cliente.
    *   `TicketController.php`: Gestión de tickets de soporte por parte del cliente.
    *   `TransactionController.php`: Visualización de transacciones del cliente.

*   **Controladores Compartidos / Comunes:**
    *   `AuthController.php`: Autenticación de usuarios (login, registro, logout), utilizada tanto por clientes como por administradores.
    *   `GoogleLoginController.php`: Manejo del inicio de sesión con Google, común a ambos roles.
    *   `TwoFactorController.php`: Gestión de la autenticación de dos factores, común a ambos roles.
    *   `BillingCycleController.php`: Gestión de ciclos de facturación. Aunque las rutas de admin existen, el controlador base podría ser compartido si la lógica es similar.
    *   `CategoryController.php`: Gestión de categorías. Similar al anterior, podría ser compartido.
    *   `ProductController.php`: Gestión de productos. Utilizado por rutas públicas y por admin con alias. La lógica base podría ser compartida.
    *   `ServicePlanController.php`: Gestión de planes de servicio. Similar a los anteriores.
    *   `StripeWebhookController.php`: Manejo de webhooks de Stripe, es una funcionalidad de backend que sirve a ambos.
    *   `Controller.php`: Controlador base de Laravel.

**Observaciones Adicionales:**
- La existencia de controladores como `ProductController` y `AdminProductController` (y similares para Categorías, Ciclos de Facturación, Planes de Servicio) sugiere que hay una duplicidad o una separación parcial de responsabilidades. La refactorización debería consolidar o clarificar esta separación.
- Los controladores `BillingCycleController`, `CategoryController`, `ProductController`, y `ServicePlanController` son utilizados tanto en `api.php` (público) como en `web.php` (protegido y admin con alias). Esto indica que contienen lógica que es relevante para ambos contextos (cliente y admin), lo que refuerza la necesidad de una estructura modular clara.

**Plan de Refactorización para Controladores:**
Se propone crear subdirectorios dentro de `app/Http/Controllers` como `Client`, `Admin`, y `Common` (o `Auth`).
- Los controladores específicos de cliente irán a `app/Http/Controllers/Client`.
- Los controladores específicos de administrador irán a `app/Http/Controllers/Admin`.
- Los controladores de autenticación y aquellos que sirven a ambos módulos con lógica compartida irán a `app/Http/Controllers/Common` o `app/Http/Controllers/Auth`.
- Se revisarán los controladores que actualmente tienen versiones `Admin` y no `Admin` para determinar si la lógica puede ser unificada o si deben mantenerse separados en sus respectivos módulos.
- Se actualizarán los `namespaces` y las referencias en las rutas y otros archivos para reflejar la nueva ubicación de los controladores.


## Análisis de Modelos (`app/Models`)

Los modelos representan las entidades de datos de la aplicación y son generalmente compartidos entre los módulos de Cliente y Administrador, ya que ambos operan sobre las mismas entidades de base de datos. Sin embargo, es importante entender qué modelos están más relacionados con cada módulo para organizar mejor la lógica de negocio.

**Modelos identificados:**

*   **Modelos de Autenticación y Usuario:**
    *   `User.php`: Modelo principal de usuario, utilizado por ambos módulos.
    *   `UserSession.php`: Gestión de sesiones de usuario, común a ambos módulos.

*   **Modelos de Servicios y Productos:**
    *   `Service.php`: Servicios contratados por los clientes, gestionados tanto por clientes como por administradores.
    *   `ServicePlan.php`: Planes de servicio disponibles, configurados por administradores y utilizados por clientes.
    *   `Product.php`: Productos disponibles, similar a los planes de servicio.
    *   `Category.php`: Categorías de productos/servicios, configuradas por administradores y utilizadas por clientes.
    *   `AddOn.php`: Complementos para servicios, gestionados por administradores y utilizados por clientes.
    *   `ServiceAddOn.php`: Relación entre servicios y complementos.
    *   `PlanFeature.php`: Características de los planes de servicio.
    *   `PlanPricing.php`: Precios de los planes de servicio.
    *   `BillingCycle.php`: Ciclos de facturación, configurados por administradores y utilizados por clientes.

*   **Modelos de Facturación y Pagos:**
    *   `Invoice.php`: Facturas generadas para los clientes, gestionadas por ambos módulos.
    *   `InvoiceItem.php`: Elementos de las facturas.
    *   `ServiceInvoice.php`: Relación entre servicios y facturas.
    *   `PaymentMethod.php`: Métodos de pago de los clientes, gestionados principalmente por clientes.
    *   `Transaction.php`: Transacciones de pago, visibles para clientes y gestionadas por administradores.
    *   `Subscription.php`: Suscripciones de los clientes, gestionadas por ambos módulos.

*   **Modelos de Soporte:**
    *   `Ticket.php`: Tickets de soporte creados por clientes y gestionados por administradores.
    *   `TicketReply.php`: Respuestas a los tickets, creadas por clientes y agentes.
    *   `Agent.php`: Agentes de soporte, gestionados por administradores.

*   **Modelos de Infraestructura:**
    *   `Domain.php`: Dominios gestionados por clientes.
    *   `ServerNode.php`: Nodos de servidor, probablemente gestionados por administradores.

*   **Modelos de Auditoría:**
    *   `ActivityLog.php`: Registro de actividades, utilizado para auditoría por administradores.

## Análisis de Requests (`app/Http/Requests`)

Actualmente, solo existen requests específicos para el módulo de administrador en `app/Http/Requests/Admin`, lo que sugiere que la validación de datos para las funcionalidades de cliente se está realizando directamente en los controladores o no se está utilizando el patrón de Form Requests de Laravel.

**Requests identificados:**
*   `Admin/StoreAddOnRequest.php`: Validación para crear complementos (Add-ons) por parte del administrador.
*   `Admin/UpdateAddOnRequest.php`: Validación para actualizar complementos por parte del administrador.

**Observaciones:**
- La falta de requests para el módulo de cliente indica una oportunidad de mejora en la validación de datos y la separación de responsabilidades.
- Durante la refactorización, se deberían crear requests tanto para el módulo de cliente como para el de administrador, organizándolos en subdirectorios correspondientes.

## Análisis de Middlewares (`app/Http/Middleware`)

Los middlewares son componentes transversales que se aplican a las rutas para realizar validaciones, autenticación, autorización, y otras funciones. Aunque no se ha examinado en detalle el contenido de cada middleware, se pueden identificar algunos por su nombre:

**Middlewares identificados:**
*   `AdminMiddleware.php`: Middleware para verificar que el usuario tiene permisos de administrador.
*   `Authenticate.php`: Middleware de autenticación estándar de Laravel.
*   `ApiResponseMiddleware.php`: Middleware personalizado para formatear respuestas de API.
*   `TrackUserSession.php`: Middleware para rastrear sesiones de usuario.
*   Otros middlewares estándar de Laravel para CSRF, CORS, etc.

**Observaciones:**
- Los middlewares son generalmente compartidos entre módulos, pero algunos como `AdminMiddleware` son específicos para el módulo de administrador.
- Durante la refactorización, se mantendrán en su ubicación actual, pero se revisarán para asegurar que están correctamente configurados y documentados.


# Diseño de Nueva Arquitectura Modular

Basándose en el análisis realizado, se propone una nueva arquitectura modular que separe claramente las responsabilidades entre los módulos de Cliente y Administrador, manteniendo componentes comunes donde sea apropiado. Esta arquitectura busca mejorar la mantenibilidad, escalabilidad y claridad del código.

## Principios de Diseño

La nueva arquitectura se basa en los siguientes principios:

**Separación de Responsabilidades**: Cada módulo (Cliente y Administrador) tendrá sus propios controladores, requests, y rutas, evitando la mezcla de lógica de negocio entre diferentes tipos de usuarios.

**Reutilización de Código Común**: Los modelos, middlewares de autenticación, y servicios compartidos se mantendrán en ubicaciones comunes para evitar duplicación de código.

**Escalabilidad**: La estructura permitirá agregar nuevos módulos en el futuro (por ejemplo, un módulo de API para terceros) sin afectar los módulos existentes.

**Claridad y Mantenibilidad**: La organización de archivos será intuitiva, permitiendo a los desarrolladores identificar rápidamente dónde se encuentra la lógica relacionada con cada funcionalidad.

**Compatibilidad con Laravel**: La estructura respetará las convenciones de Laravel y no requerirá cambios significativos en la configuración del framework.

## Estructura de Directorios Propuesta

### Controladores (`app/Http/Controllers`)

```
app/Http/Controllers/
├── Controller.php                    # Controlador base de Laravel
├── Auth/                            # Controladores de autenticación compartidos
│   ├── AuthController.php
│   ├── GoogleLoginController.php
│   └── TwoFactorController.php
├── Common/                          # Controladores compartidos entre módulos
│   └── StripeWebhookController.php
├── Client/                          # Controladores específicos del módulo Cliente
│   ├── DashboardController.php
│   ├── ProfileController.php
│   ├── ServiceController.php
│   ├── PaymentController.php
│   ├── SubscriptionController.php
│   ├── TicketController.php
│   ├── InvoiceController.php
│   ├── TransactionController.php
│   ├── DomainController.php
│   ├── ProductController.php
│   ├── CategoryController.php
│   ├── BillingCycleController.php
│   ├── ServicePlanController.php
│   └── AddOnController.php
└── Admin/                           # Controladores específicos del módulo Administrador
    ├── AdminController.php
    ├── AgentController.php
    ├── UserController.php
    ├── ServiceController.php
    ├── InvoiceController.php
    ├── TicketController.php
    ├── ProductController.php
    ├── CategoryController.php
    ├── BillingCycleController.php
    ├── ServicePlanController.php
    └── AddOnController.php
```

### Requests (`app/Http/Requests`)

```
app/Http/Requests/
├── Auth/                            # Requests de autenticación
│   ├── LoginRequest.php
│   ├── RegisterRequest.php
│   └── TwoFactorRequest.php
├── Client/                          # Requests del módulo Cliente
│   ├── Profile/
│   │   ├── UpdateProfileRequest.php
│   │   ├── UpdateEmailRequest.php
│   │   └── UpdatePasswordRequest.php
│   ├── Service/
│   │   ├── ContractServiceRequest.php
│   │   └── UpdateServiceConfigRequest.php
│   ├── Payment/
│   │   ├── AddPaymentMethodRequest.php
│   │   └── ProcessPaymentRequest.php
│   ├── Ticket/
│   │   ├── CreateTicketRequest.php
│   │   └── ReplyTicketRequest.php
│   └── Domain/
│       ├── CreateDomainRequest.php
│       └── UpdateDomainRequest.php
└── Admin/                           # Requests del módulo Administrador
    ├── User/
    │   ├── CreateUserRequest.php
    │   └── UpdateUserRequest.php
    ├── Service/
    │   └── UpdateServiceStatusRequest.php
    ├── Product/
    │   ├── CreateProductRequest.php
    │   └── UpdateProductRequest.php
    ├── Category/
    │   ├── CreateCategoryRequest.php
    │   └── UpdateCategoryRequest.php
    ├── ServicePlan/
    │   ├── CreateServicePlanRequest.php
    │   └── UpdateServicePlanRequest.php
    ├── AddOn/
    │   ├── StoreAddOnRequest.php      # Ya existe
    │   └── UpdateAddOnRequest.php     # Ya existe
    └── Agent/
        ├── CreateAgentRequest.php
        └── UpdateAgentRequest.php
```

### Rutas (`routes/`)

```
routes/
├── api.php                          # Rutas públicas (sin autenticación)
├── web.php                          # Rutas base y configuración
├── auth.php                         # Rutas de autenticación
├── client.php                       # Rutas del módulo Cliente
└── admin.php                        # Rutas del módulo Administrador
```

### Modelos (`app/Models`)

Los modelos se mantendrán en su ubicación actual (`app/Models`) ya que representan entidades de datos compartidas entre módulos. Sin embargo, se pueden organizar en subdirectorios temáticos si el número de modelos crece significativamente:

```
app/Models/
├── User.php
├── UserSession.php
├── Service/
│   ├── Service.php
│   ├── ServicePlan.php
│   ├── ServiceAddOn.php
│   └── ServiceInvoice.php
├── Billing/
│   ├── Invoice.php
│   ├── InvoiceItem.php
│   ├── PaymentMethod.php
│   ├── Transaction.php
│   ├── Subscription.php
│   └── BillingCycle.php
├── Product/
│   ├── Product.php
│   ├── Category.php
│   ├── AddOn.php
│   ├── PlanFeature.php
│   └── PlanPricing.php
├── Support/
│   ├── Ticket.php
│   ├── TicketReply.php
│   └── Agent.php
├── Infrastructure/
│   ├── Domain.php
│   └── ServerNode.php
└── ActivityLog.php
```

## Estrategia de Migración

### Fase 1: Creación de Estructura de Directorios

Se crearán los nuevos directorios para los módulos Cliente y Administrador dentro de `app/Http/Controllers` y `app/Http/Requests`.

### Fase 2: Migración de Controladores

**Controladores de Autenticación**: Se moverán `AuthController`, `GoogleLoginController`, y `TwoFactorController` al directorio `Auth/`.

**Controladores Compartidos**: `StripeWebhookController` se moverá al directorio `Common/`.

**Controladores de Cliente**: Se moverán los controladores identificados como específicos del cliente al directorio `Client/`. Algunos controladores que actualmente sirven tanto a rutas públicas como a rutas de cliente se duplicarán o se refactorizarán para separar la lógica.

**Controladores de Administrador**: Se moverán los controladores específicos del administrador al directorio `Admin/`. El `AdminController` se refactorizará para separar sus múltiples responsabilidades en controladores específicos.

### Fase 3: Actualización de Namespaces

Se actualizarán los namespaces de todos los controladores movidos para reflejar su nueva ubicación:
- `App\Http\Controllers\Auth\AuthController`
- `App\Http\Controllers\Client\DashboardController`
- `App\Http\Controllers\Admin\UserController`

### Fase 4: Creación de Requests

Se crearán Form Requests para validar los datos de entrada en ambos módulos, siguiendo las mejores prácticas de Laravel.

### Fase 5: Refactorización de Rutas

Se reorganizarán las rutas en archivos separados:
- `routes/auth.php`: Rutas de autenticación (login, registro, 2FA)
- `routes/client.php`: Rutas del módulo Cliente
- `routes/admin.php`: Rutas del módulo Administrador
- `routes/api.php`: Se mantendrá para rutas públicas
- `routes/web.php`: Se simplificará para incluir solo configuración base

### Fase 6: Actualización de Referencias

Se actualizarán todas las referencias a los controladores en:
- Archivos de rutas
- Tests
- Otros archivos que puedan importar directamente los controladores

## Beneficios de la Nueva Arquitectura

**Mantenibilidad Mejorada**: Los desarrolladores podrán localizar rápidamente el código relacionado con funcionalidades específicas de cliente o administrador.

**Reducción de Conflictos**: Al separar los módulos, se reduce la probabilidad de que cambios en funcionalidades de administrador afecten accidentalmente las funcionalidades de cliente, y viceversa.

**Escalabilidad**: La estructura modular permite agregar nuevos módulos (como APIs para terceros, módulos de reportes, etc.) sin afectar los módulos existentes.

**Testing Mejorado**: Los tests pueden organizarse de manera similar, facilitando la escritura y mantenimiento de pruebas específicas para cada módulo.

**Onboarding de Desarrolladores**: Los nuevos desarrolladores podrán entender más rápidamente la estructura del proyecto y contribuir de manera más efectiva.

**Deployment Selectivo**: En el futuro, si es necesario, se podrían desplegar módulos específicos de manera independiente.

Esta arquitectura modular proporciona una base sólida para el crecimiento y mantenimiento a largo plazo de la plataforma de hosting, asegurando que el código permanezca organizado, mantenible y escalable.


# Análisis de Datos Hardcodeados y Servicios de Terceros

## Servicios de Terceros Identificados

Basándose en el análisis del código, las migraciones de base de datos y el archivo `.env.example`, se han identificado los siguientes servicios de terceros que requieren configuración e integración:

### 1. Proxmox VE (Virtualización)
**Propósito**: Gestión de máquinas virtuales y contenedores para servicios de hosting.

**Configuración requerida en `.env`:**
```env
PROXMOX_URL=https://proxmox.yourdomain.com:8006
PROXMOX_USERNAME=api@pve
PROXMOX_PASSWORD=secure_api_password
PROXMOX_DEFAULT_NODE=pve
```

**Estado de integración**: 
- ✅ Estructura de base de datos preparada (tabla `server_nodes` con tipo `proxmox`)
- ❌ **FALTA IMPLEMENTAR**: Lógica de integración con la API de Proxmox
- ❌ **FALTA IMPLEMENTAR**: Creación automática de VMs/Contenedores
- ❌ **FALTA IMPLEMENTAR**: Gestión de recursos y monitoreo

**Comentarios para implementación**:
```php
// TODO: Implementar integración con Proxmox API
// Instalar en servidor: Proxmox VE 7.x o superior
// Configurar usuario API con permisos adecuados
// Implementar cliente HTTP para comunicación con API REST de Proxmox
```

### 2. Pterodactyl Panel (Gestión de Servidores de Juegos)
**Propósito**: Gestión de servidores de juegos (Minecraft, CS:GO, etc.).

**Configuración requerida en `.env`:**
```env
PTERODACTYL_URL=https://panel.yourdomain.com
PTERODACTYL_API_KEY=your_application_api_key
```

**Estado de integración**:
- ✅ Estructura de base de datos preparada (tabla `server_nodes` con tipo `pterodactyl`)
- ❌ **FALTA IMPLEMENTAR**: Lógica de integración con la API de Pterodactyl
- ❌ **FALTA IMPLEMENTAR**: Creación automática de servidores de juegos
- ❌ **FALTA IMPLEMENTAR**: Gestión de configuraciones y mods

**Comentarios para implementación**:
```php
// TODO: Implementar integración con Pterodactyl API
// Instalar en servidor: Pterodactyl Panel v1.x
// Configurar Application API Key con permisos de escritura
// Implementar cliente para API REST de Pterodactyl
```

### 3. Stripe (Procesamiento de Pagos)
**Propósito**: Procesamiento de pagos y gestión de suscripciones.

**Configuración requerida en `.env`:**
```env
STRIPE_KEY=pk_test_your_stripe_key
STRIPE_SECRET=sk_test_your_stripe_secret
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
```

**Estado de integración**:
- ✅ **IMPLEMENTADO**: Integración básica con Stripe
- ✅ **IMPLEMENTADO**: Procesamiento de pagos
- ✅ **IMPLEMENTADO**: Gestión de métodos de pago
- ✅ **IMPLEMENTADO**: Webhooks para eventos de Stripe
- ⚠️ **REVISAR**: Configurar webhooks en producción

### 4. PayPal (Procesamiento de Pagos Alternativo)
**Propósito**: Procesamiento de pagos alternativo a Stripe.

**Configuración requerida en `.env`:**
```env
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
PAYPAL_MODE=sandbox
```

**Estado de integración**:
- ❌ **FALTA IMPLEMENTAR**: Integración completa con PayPal
- ❌ **FALTA IMPLEMENTAR**: Procesamiento de pagos PayPal
- ❌ **FALTA IMPLEMENTAR**: Webhooks de PayPal

### 5. Namecheap (Registrador de Dominios)
**Propósito**: Registro y gestión de nombres de dominio.

**Configuración requerida en `.env`:**
```env
NAMECHEAP_API_USER=your_username
NAMECHEAP_API_KEY=your_api_key
NAMECHEAP_CLIENT_IP=your_server_ip
NAMECHEAP_SANDBOX=true
```

**Estado de integración**:
- ❌ **FALTA IMPLEMENTAR**: Integración con API de Namecheap
- ❌ **FALTA IMPLEMENTAR**: Registro automático de dominios
- ❌ **FALTA IMPLEMENTAR**: Gestión de DNS y renovaciones

### 6. Servicios de Email (SMTP)
**Propósito**: Envío de emails transaccionales y notificaciones.

**Configuración requerida en `.env`:**
```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.mailgun.org
MAIL_PORT=587
MAIL_USERNAME=your_username
MAIL_PASSWORD=your_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@yourdomain.com
MAIL_FROM_NAME="${APP_NAME}"
```

**Estado de integración**:
- ⚠️ **CONFIGURAR**: Servicio SMTP (Mailgun, SendGrid, etc.)

## Datos Hardcodeados Identificados

### 1. Configuraciones de Desarrollo
**Ubicación**: Archivos de configuración en `config/`
**Datos encontrados**:
- URLs localhost en configuraciones por defecto
- IPs 127.0.0.1 en configuraciones de cache y base de datos
- Dominios de desarrollo en CORS y Sanctum

**Recomendación**: ✅ Ya están correctamente configurados para usar variables de entorno.

### 2. Configuraciones de Moneda y País
**Ubicación**: `.env.example`
**Datos encontrados**:
```env
DEFAULT_CURRENCY=USD
DEFAULT_COUNTRY=US
INVOICE_PREFIX=INV-
TICKET_PREFIX=TKT-
```

**Estado**: ✅ Correctamente configurado para usar variables de entorno.

### 3. Configuraciones de Dominio y Sesión
**Ubicación**: `.env.example`
**Datos encontrados**:
```env
SANCTUM_STATEFUL_DOMAINS=localhost,127.0.0.1,127.0.0.1:3000,::1,yourdomain.com
SESSION_DOMAIN=.yourdomain.com
```

**Recomendación**: ⚠️ Actualizar `yourdomain.com` con el dominio real en producción.

## Servicios de Infraestructura Adicionales Requeridos

### 1. Redis
**Propósito**: Cache y gestión de sesiones.
**Estado**: ✅ Configurado en `.env.example`
**Instalación requerida**: Redis Server en el servidor de producción.

### 2. MySQL/MariaDB
**Propósito**: Base de datos principal.
**Estado**: ✅ Configurado en `.env.example`
**Instalación requerida**: MySQL 8.0+ o MariaDB 10.5+ en el servidor de producción.

### 3. Supervisor (Opcional)
**Propósito**: Gestión de colas de trabajo en background.
**Estado**: ❌ No configurado
**Recomendación**: Configurar para gestión de trabajos de creación de servicios.

## Recomendaciones de Seguridad

### 1. Encriptación de Credenciales de API
**Ubicación**: Campo `api_credentials` en tabla `server_nodes`
**Estado**: ✅ Diseñado para almacenar credenciales encriptadas
**Recomendación**: Implementar encriptación usando `encrypt()` de Laravel.

### 2. Validación de Webhooks
**Estado**: ✅ Implementado para Stripe
**Recomendación**: Implementar validación similar para otros servicios (PayPal, etc.).

### 3. Rate Limiting
**Estado**: ⚠️ Revisar implementación
**Recomendación**: Configurar rate limiting para APIs de terceros.

## Próximos Pasos para Integración

1. **Proxmox**: Instalar Proxmox VE y configurar usuario API
2. **Pterodactyl**: Instalar Pterodactyl Panel y generar Application API Key
3. **PayPal**: Configurar aplicación PayPal y implementar SDK
4. **Namecheap**: Configurar cuenta API y implementar cliente
5. **Email**: Configurar servicio SMTP (Mailgun recomendado)
6. **Infraestructura**: Instalar Redis, MySQL, y configurar Supervisor

Cada servicio requerirá implementación específica de clientes API y lógica de negocio para integración completa con la plataforma de hosting.

